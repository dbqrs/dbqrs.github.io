PL2303 driver for the fake PL2303 chip, often found in the Baofeng and 
other radio programming cables. 

Works on Windows 7,8,10 & 11

1. Go to add/remove programs and uninstall any software for your cable. 
    
2. Plug in cable and go to device manager.  Right click on device and 
select uninstall. Check the box that says delete the software for this 
device.
    
3. Once completed, unplug the programming cable and restart.

4. Leave the cable unplugged and disconnect from the internet.
    
5. Install the software with the cable unplugged. Once it's finished 
plug in the cable and check device manager.


0/69 Detections on VirusTotal
https://www.virustotal.com/gui/file/81993c22b2daa5cd3c0efaee68cfc4a7100fd5956ea8da06346cf42cf3373aff

Before installing, as a precaution, check this file on VirusTotal.com yourself.

SHA256:
81993c22b2daa5cd3c0efaee68cfc4a7100fd5956ea8da06346cf42cf3373aff *PL2303_Driver.exe

